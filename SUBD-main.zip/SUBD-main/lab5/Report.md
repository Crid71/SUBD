Звіт до роботи 5
Тема: Тестування
Мета роботи: Перевірка assert
Виконання роботи
Це процес перевірки правильності роботи програм, їх функцій та поведінки при різних умовах роботи шляхом створення штучних ситуацій або сценаріїв.
![alt text](https://github.com/11MaDmAn18/SUBD/blob/main/lab5/srclab5/src1_5.png "Результат")
Для роботи нам буде потрібно створити декілька Python файлів.
Перевірка assert
![alt text](https://github.com/11MaDmAn18/SUBD/blob/main/lab5/srclab5/src2_5.png "Результат")
![alt text](https://github.com/11MaDmAn18/SUBD/blob/main/lab5/srclab5/src3_5.png "Результат")

Юніт тести
![alt text](https://github.com/11MaDmAn18/SUBD/blob/main/lab5/srclab5/src4_5.png "Результат")

Юніт тести з використання бібліотеки PyTest
![alt text](https://github.com/11MaDmAn18/SUBD/blob/main/lab5/srclab5/src5_5.png "Результат")
Візуалізація результатів та покриття коду Coverage (pytest-cov)
![alt text](https://github.com/11MaDmAn18/SUBD/blob/main/lab5/srclab5/src6_5.png "Результат")
![alt text](https://github.com/11MaDmAn18/SUBD/blob/main/lab5/srclab5/src7_5.png "Результат")
Висновок:

❓ Що зроблено в роботі; 
- Тестування.

❓ Чи досягнуто мети роботи; 
- Так

❓ Які нові знання отримано; 
- Тестування, покриття коду тестами, виклик помилок.

❓ Чи вдалось відповісти на всі питання задані в ході роботи; 
- Так

❓ Чи вдалося виконати всі завдання;
-  Так

❓ Чи виникли складності у виконанні завдання; 
- Ні

❓ Чи подобається такий формат здачі роботи (Feedback); 
- Загалом так

❓ Побажання для покращення (Suggestions); 
- -

