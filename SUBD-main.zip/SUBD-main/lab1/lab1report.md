# Звіт до роботи
## Тема: Перша програма на Python
### Мета роботи: Навчитись створювати файли Python і т.д.
---
### Виконання роботи
- Результати виконання завдання 1;
   Створив файл першої програми, вставив код:
```python
from datetime import datetime
name = "Dmytro"

print(f"{name} start programming at {datetime.now()}")
```
   Програма вивела значення "Dmytro start programming at 2022-09-01 08:20:42.649536"

- Результати виконання завдання 2;
   Створив файл з розширенням .ipynb, вставив код:
```python
from datetime import datetime
name = "Dmytro"

print(f"{name} start programming at {datetime.now()}")
```
   Програма вивела значення "Dmytro start programming at 2022-10-27 13:39:28.026029":

![alt text](https://github.com/11MaDmAn18/SUBD/blob/main/lab1/src/src_lab1_1.png "Результат")

   Додав ще одну комірку з типом Markdown, результат:

![alt text](https://github.com/11MaDmAn18/SUBD/blob/main/lab1/src/src_lab1_2.png "Результат")

### Висновок: 
    Я скачав Python, навчився створювати файли .py .ipynb та редагувати їх. Виконав всі завдання, складнощів не виникло.
- :question: Чи подобається такий формат здачі роботи (Feedback);
Так
---