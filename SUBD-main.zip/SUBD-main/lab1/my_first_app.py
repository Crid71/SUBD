from datetime import datetime
name = "Dmytro"

print(f"{name} start programming at {datetime.now()}")
