# Звіт до роботи 2
## Тема: Основи програмування на Python
### Мета роботи: ознайомитись з основами програмування на Python
---
### Виконання роботи
- Результати виконання завдання:
    1. Основні типи даних:

    ![alt text]( https://github.com/11MaDmAn18/SUBD/blob/main/lab2/srclab2/src1_2.png "Результат виконання завдання")
    
    2. Вбудовані константи:

    ![alt text]( https://github.com/11MaDmAn18/SUBD/blob/main/lab2/srclab2/src2_2.png "Результат виконання завдання")
    
    3. Результат роботи вбудованих функцій:

    ![alt text]( https://github.com/11MaDmAn18/SUBD/blob/main/lab2/srclab2/src3_2.png "Результат виконання завдання")
    
    4. Цикли:

    ![alt text]( https://github.com/11MaDmAn18/SUBD/blob/main/lab2/srclab2/src4_2.png "Результат виконання завдання")
    
    5. Розгалуження:

    ![alt text]( https://github.com/11MaDmAn18/SUBD/blob/main/lab2/srclab2/src5_2.png "Результат виконання завдання")
    
    6. Конструкція try->except->finally:

    
    7. Контекст-менеджер with:

    
    8. Lambda:

    ![alt text](https://github.com/11MaDmAn18/SUBD/blob/main/lab2/srclab2/src678_2.png "Результат виконання завдання")

### Висновок: 
- :question: Що зроблено в роботі;
Вивчено новий матеріал
- :question: Чи досягнуто мети роботи;
Так
- :question: Які нові знання отримано;
Різні
- :question: Чи вдалось відповісти на всі питання задані в ході роботи;
Так
- :question: Чи вдалося виконати всі завдання;
Так
- :question: Чи виникли складності у виконанні завдання;
Ні
- :question: Чи подобається такий формат здачі роботи (Feedback);
Так
- :question: Побажання для покращення (Suggestions);
Немає
---