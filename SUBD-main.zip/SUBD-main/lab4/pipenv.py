import requests

response = requests.get('https://httpbin.org/')
for line in response.iter_lines():
    print(line)
