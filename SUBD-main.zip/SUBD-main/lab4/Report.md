Звіт до роботи 4
Тема: Віртуальні середовища, робота у віртуальному середовищі
Мета роботи: Ознайомитись з віртуальними середовищами, навчитись працювати в них
Виконання роботи
Віртуальні середовища:

Перевірив, чи встановлений pip та виконав pip --help:

![alt text](https://github.com/11MaDmAn18/SUBD/blob/main/lab4/srclab4/src1_4.png "Результат")

Інстальовані бібліотеки:
Встановив requests.

![alt text](https://github.com/11MaDmAn18/SUBD/blob/main/lab4/srclab4/src2(1)_4.png "Результат")

Ознайомився.

Виконав команди.

Робота у віртуальному середовищі:

Створив VENV та виконав команди.

![alt text](https://github.com/11MaDmAn18/SUBD/blob/main/lab4/srclab4/src4_4.png "Результат")

Інші скріни:
![alt text](https://github.com/11MaDmAn18/SUBD/blob/main/lab4/srclab4/src9_4.png "Результат")
![alt text](https://github.com/11MaDmAn18/SUBD/blob/main/lab4/srclab4/src_pipenv%20--help_4.png "Результат")
![alt text](https://github.com/11MaDmAn18/SUBD/blob/main/lab4/srclab4/srccomnds_4.png "Результат")
![alt text](https://github.com/11MaDmAn18/SUBD/blob/main/lab4/srclab4/srcdoing_4.png "Результат")

Висновок:
❓ Що зроблено в роботі;
Ознайомився з віртуальними середовищами
❓ Чи досягнуто мети роботи;
Так
❓ Які нові знання отримано;
Знання про віртуальні середовища
❓ Чи вдалось відповісти на всі питання задані в ході роботи;
Так
❓ Чи вдалося виконати всі завдання;
Так
❓ Чи виникли складності у виконанні завдання;
Ні
❓ Чи подобається такий формат здачі роботи (Feedback);
Так
❓ Побажання для покращення (Suggestions);
-