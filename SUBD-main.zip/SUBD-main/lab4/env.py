import os
print(os.environ['HELLO'])


