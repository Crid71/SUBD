

## Технології представлення даних у СУБД.
### ТК-41, Mazepa D. A.
## Список для робіт:
1. [Перше завдання](https://github.com/11MaDmAn18/SUBD/tree/main/lab1)
2. [Друге завдання](https://github.com/11MaDmAn18/SUBD/tree/main/lab2)
3. [Третє завдання](https://github.com/11MaDmAn18/SUBD/tree/main/lab3)
4. [Четверте завдання](https://github.com/11MaDmAn18/SUBD/tree/main/lab4)
5. [П'яте завдання](https://github.com/11MaDmAn18/SUBD/tree/main/lab5)
6. ...
7. ...